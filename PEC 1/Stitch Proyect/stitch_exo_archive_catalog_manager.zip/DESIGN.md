---
name: EXO-ARCHIVE
colors:
  surface: '#121414'
  surface-dim: '#121414'
  surface-bright: '#38393a'
  surface-container-lowest: '#0d0e0f'
  surface-container-low: '#1a1c1c'
  surface-container: '#1e2020'
  surface-container-high: '#282a2b'
  surface-container-highest: '#333535'
  on-surface: '#e2e2e2'
  on-surface-variant: '#bbc9cf'
  inverse-surface: '#e2e2e2'
  inverse-on-surface: '#2f3131'
  outline: '#859399'
  outline-variant: '#3c494e'
  surface-tint: '#47d6ff'
  primary: '#a5e7ff'
  on-primary: '#003543'
  primary-container: '#00d2ff'
  on-primary-container: '#00566a'
  inverse-primary: '#00677f'
  secondary: '#9ccee1'
  on-secondary: '#003543'
  secondary-container: '#184f5f'
  on-secondary-container: '#8ec0d3'
  tertiary: '#ffd79f'
  on-tertiary: '#442b00'
  tertiary-container: '#ffb229'
  on-tertiary-container: '#6c4700'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#b6ebff'
  primary-fixed-dim: '#47d6ff'
  on-primary-fixed: '#001f28'
  on-primary-fixed-variant: '#004e60'
  secondary-fixed: '#b7eafe'
  secondary-fixed-dim: '#9ccee1'
  on-secondary-fixed: '#001f28'
  on-secondary-fixed-variant: '#154d5d'
  tertiary-fixed: '#ffddb1'
  tertiary-fixed-dim: '#ffba4a'
  on-tertiary-fixed: '#291800'
  on-tertiary-fixed-variant: '#624000'
  background: '#121414'
  on-background: '#e2e2e2'
  surface-variant: '#333535'
typography:
  display-lg:
    fontFamily: Inter
    fontSize: 48px
    fontWeight: '700'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '600'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.2'
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  data-mono:
    fontFamily: JetBrains Mono
    fontSize: 14px
    fontWeight: '500'
    lineHeight: '1.4'
    letterSpacing: 0.02em
  label-caps:
    fontFamily: JetBrains Mono
    fontSize: 11px
    fontWeight: '700'
    lineHeight: 12px
    letterSpacing: 0.1em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  base: 8px
  xs: 4px
  sm: 12px
  md: 24px
  lg: 48px
  xl: 80px
  gutter: 24px
  margin-safe: 32px
---

## Brand & Style
The brand personality is clinical, precise, and expansive. Targeted at researchers and astronomical enthusiasts, the design system evokes the feeling of a high-end interstellar observatory interface. 

The style utilizes a **Minimalist Glassmorphism** approach. By combining deep space backgrounds with translucent, high-blur panels, the UI creates a sense of depth and focus. The aesthetic avoids unnecessary ornamentation, ensuring that the scientific data remains the primary focus. Visual interest is generated through light refraction and subtle "haze" effects rather than heavy color use.

## Colors
The palette is intentionally restrained to maintain a "dark-room" environment suitable for long-term data analysis.

- **Primary (#00d2ff):** A high-energy cyan used exclusively for interactive elements, progress indicators, and critical data highlights.
- **Background (#0a0c10):** A deep, near-black ink blue that provides the infinite canvas for the UI.
- **Text/Neutral (#e0e0e0):** A soft light gray to prevent eye strain while maintaining high legibility against the dark background.
- **Glass Layers:** Surfaces use a white-tinted transparency at very low opacity (3-5%) combined with a 20px background blur to create separation without adding visual weight.

## Typography
The system uses **Inter** for all narrative and structural text due to its exceptional legibility in digital interfaces. To handle the technical nature of exoplanet data (coordinates, masses, distances), **JetBrains Mono** is introduced for numerical values and labels.

Numerical data should always be set in the `data-mono` role to ensure tabular alignment and easy comparison between rows. Headers use tight tracking and bold weights to ground the sections.

## Layout & Spacing
This design system employs a **12-column fluid grid** for desktop, collapsing to a **4-column grid** on mobile.

The spacing rhythm is built on an 8px base unit. 
- **Desktop:** 32px safe margins with 24px gutters. Content should be grouped into translucent modules (cards) that span defined column widths (e.g., 4-col for sidebar, 8-col for main data visualization).
- **Mobile:** Margins reduce to 16px. Elements stack vertically, prioritizing data charts and then tabular metadata.
- **Alignment:** All technical data labels must be top-aligned with their corresponding values.

## Elevation & Depth
Depth is created through **Glassmorphism** rather than traditional drop shadows.

- **Level 0 (Background):** Solid #0a0c10.
- **Level 1 (Main Panels):** 3% white opacity, 20px background blur, and a 1px solid border at 8% white opacity. This creates a "frosted" look.
- **Level 2 (Modals/Popovers):** 6% white opacity, 40px background blur. These layers should have a subtle inner glow (1px top-border) to simulate light catching the edge of the glass.
- **Interaction:** Hovering over a glass panel should increase the border opacity to 15%, creating a tactile response.

## Shapes
The shape language is **Soft** and precision-oriented. 

Corners are slightly rounded (4px to 12px) to prevent the interface from feeling overly aggressive or "brutalist," while maintaining a professional, technical edge. Buttons and inputs use a standard 4px radius, while large data cards use an 8px radius to define larger layout blocks. High-radius "pill" shapes are reserved exclusively for status badges (e.g., "Confirmed," "Candidate").

## Components
- **Buttons:** Primary buttons are solid Cyan (#00d2ff) with black text. Secondary buttons are ghost-style with 1px Cyan borders and no fill.
- **Cards:** Defined by the Level 1 glass elevation. They should not have shadows. Padding inside cards is strictly 24px.
- **Data Tables:** Row separators are 1px lines at 5% white opacity. Hovering over a row should highlight it with a 5% cyan tint.
- **Input Fields:** Darker than the background (#050608), 1px gray border, 4px radius. Focus state uses a Cyan glow (2px blur).
- **Toggles:** Minimalist switch design. When active, the track is Cyan. When inactive, it is a dark gray (#333).
- **Status Indicators:** Use small circular dots next to text (Cyan for "Confirmed," Orange for "Candidate," Gray for "Removed").